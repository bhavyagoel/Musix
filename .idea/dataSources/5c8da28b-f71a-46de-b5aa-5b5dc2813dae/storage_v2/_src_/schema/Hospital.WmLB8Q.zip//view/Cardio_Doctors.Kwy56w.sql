create definer = music@localhost view Cardio_Doctors as
select `Hospital`.`Doctor`.`Doc_ID`   AS `Doc_ID`,
       `Hospital`.`Doctor`.`Doc_Name` AS `Doc_Name`,
       `Hospital`.`Doctor`.`Gender`   AS `Gender`
from `Hospital`.`Doctor`
where (`Hospital`.`Doctor`.`Specialist` = 'Cardiology');

