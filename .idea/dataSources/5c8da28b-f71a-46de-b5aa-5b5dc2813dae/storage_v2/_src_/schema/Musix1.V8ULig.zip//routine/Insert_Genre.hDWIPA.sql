create
    definer = music@localhost procedure Insert_Genre(IN Name varchar(20), IN ID char(7))
BEGIN
    INSERT INTO Genre(Genre_ID, Name)
        VALUE
        (ID, Name);
END;

