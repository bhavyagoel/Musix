create view SongYearOrder as
select `Musix1`.`Song`.`Song_ID`  AS `Song_ID`,
       `Musix1`.`Song`.`Name`     AS `Name`,
       `Musix1`.`Song`.`Year`     AS `Year`,
       `Musix1`.`Song`.`Duration` AS `Duration`,
       `Musix1`.`Song`.`Genre_ID` AS `Genre_ID`
from `Musix1`.`Song`
where `Musix1`.`Song`.`Song_ID` in (select `Musix1`.`Song_Artist`.`Song_ID`
                                    from `Musix1`.`Song_Artist`
                                    where (`Musix1`.`Song_Artist`.`Artist_ID` = 'ARID0003'))
order by `Musix1`.`Song`.`Year` desc;

