create
    definer = music@localhost procedure Alter_Password(IN MobNum varchar(20), IN Email varchar(20),
                                                       IN userName varchar(20), IN newPass char(10))
BEGIN
    DECLARE ID CHAR(7);
    DECLARE ID_Verified CHAR(7);

    SELECT Register_ID
    INTO ID
    FROM Register
    WHERE Mobile = MobNum
      AND Email_ID = Email;

    IF ID IS NOT NULL THEN
        SELECT User_ID
        INTO ID_Verified
        FROM User
        WHERE User_ID = ID
          AND Name = userName;
    END IF;

    IF ID_Verified IS NOT NULL THEN
        UPDATE Login
        SET Password=newPass
        WHERE Login_ID = ID_Verified;
        SELECT * FROM Login WHERE Login_ID = ID_Verified;
    END IF;

    IF ID_Verified IS NULL OR ID IS NULL THEN
        SELECT "NOT AUTHORISED" AS ERROR;
    END IF;
END;

