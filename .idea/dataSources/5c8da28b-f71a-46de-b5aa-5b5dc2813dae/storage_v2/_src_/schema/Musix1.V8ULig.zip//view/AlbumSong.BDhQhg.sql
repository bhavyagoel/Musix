create view AlbumSong as
select `Musix1`.`Album`.`Name` AS `Name`, `AS`.`Song_ID` AS `Song_ID`, `Musix1`.`Album`.`Album_ID` AS `Album_ID`
from (`Musix1`.`Album`
         join `Musix1`.`Album_Song` `AS` on ((`Musix1`.`Album`.`Album_ID` = `AS`.`Album_ID`)));

