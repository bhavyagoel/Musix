create definer = music@localhost trigger ArtistAge
    before insert
    on Artist
    for each row
BEGIN
    DECLARE age1 INT;
    SET NEW.Age = TIMESTAMPDIFF(MONTH, NEW.DOB, SYSDATE()) / 12;
END;

